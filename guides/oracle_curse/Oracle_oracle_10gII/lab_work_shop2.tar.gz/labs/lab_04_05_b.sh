# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
echo rm '/u01/app/oracle/oradata/orcl/redo02b.log'
rm '/u01/app/oracle/oradata/orcl/redo02b.log'
echo
echo redo file deleted.
echo
