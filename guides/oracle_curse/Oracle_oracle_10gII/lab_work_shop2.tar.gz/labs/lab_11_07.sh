# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script creates 5 tables, enables row movement in 3 tables and
#   inserts rows into all tables.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF


create table employees1 tablespace tbsalert as select * from hr.employees;
create table employees2 tablespace tbsalert as select * from hr.employees;
create table employees3 tablespace tbsalert as select * from hr.employees;
create table employees4 tablespace tbsalert as select * from hr.employees;
create table employees5 tablespace tbsalert as select * from hr.employees;

alter table employees1 enable row movement;
alter table employees2 enable row movement;
alter table employees3 enable row movement;


BEGIN
 FOR i in 1..10 LOOP
   insert into employees1 select * from employees1;
   insert into employees2 select * from employees2;
   insert into employees3 select * from employees3;
   insert into employees4 select * from employees4;
   insert into employees5 select * from employees5;
   commit;   
 END LOOP;
END;
/


insert into employees1 select * from employees1;
insert into employees2 select * from employees2;
insert into employees3 select * from employees3;

commit;

exit;
EOF
