# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
rm /u01/app/oracle/oradata/orcl/temp01.dbf
echo
echo temp file deleted.
echo

