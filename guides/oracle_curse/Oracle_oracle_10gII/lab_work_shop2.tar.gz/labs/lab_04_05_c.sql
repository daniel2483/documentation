-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
set echo on
alter system switch logfile;
alter system switch logfile;
alter system switch logfile;
host tail -60 $ORACLE_BASE/admin/orcl/bdump/alert_orcl.log
