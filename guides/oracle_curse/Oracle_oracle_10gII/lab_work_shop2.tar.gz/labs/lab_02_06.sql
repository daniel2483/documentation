-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
set echo on

CREATE SMALLFILE TABLESPACE "STAGING" DATAFILE '/u01/app/oracle/oradata/orcl/staging01.dbf' SIZE 3M REUSE NOLOGGING EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO
/
create table hr.staging_tab tablespace staging as select * from all_objects where rownum < 11 
/
set echo off
prompt
prompt STAGING tablespace created and populated with one table.
prompt
set echo on
quit
