-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
connect / as sysdba

drop user addm cascade;

drop tablespace tbsaddm including contents and datafiles;

drop tablespace tbsaddm2 including contents and datafiles;
