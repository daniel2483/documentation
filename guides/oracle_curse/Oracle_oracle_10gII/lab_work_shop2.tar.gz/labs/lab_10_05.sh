# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script drops the HR.TEST_REGIONS table and the TEST_SEQ sequence.
#   Start this script connected as OS user: oracle.


sqlplus / as sysdba << EOF

DROP SEQUENCE test_seq;

DROP TABLE hr.test_regions CASCADE CONSTRAINTS PURGE;

exit;
EOF
