# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
# Shutdown the database
echo Shutting down the database...
sqlplus / as sysdba <<EOF
set echo on
shutdown immediate
EOF

# Copy datafiles
echo Copying datafiles...
cp /u01/app/oracle/oradata/orcl/*.* ~/DONTTOUCH

# Startup the database
echo Starting the instance...
sqlplus / as sysdba <<EOF
set echo on
startup
EOF

echo Finished.



