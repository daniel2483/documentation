# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script imports the WORDS table
#
imp system/oracle file=/home/oracle/labs/lab_16_04_a.dmp full=y log=lab_16_04_a.log