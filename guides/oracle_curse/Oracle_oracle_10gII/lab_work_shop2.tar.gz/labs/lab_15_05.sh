# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script supports the practice: Implementing TDE
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

set echo on

create user TDE_DBA identified by TDE_DBA
default tablespace users
temporary tablespace temp;

grant connect, resource, dba to TDE_DBA;

connect TDE_DBA/TDE_DBA

CREATE SMALLFILE TABLESPACE "TDE"
DATAFILE 'tde1.dbf' SIZE 500K
LOGGING
EXTENT MANAGEMENT LOCAL
SEGMENT SPACE MANAGEMENT AUTO;

drop table emp_enc purge;

CREATE TABLE emp_enc (
     first_name VARCHAR2(20),
     last_name VARCHAR2(20),
     empID NUMBER,
     salary NUMBER(6) ENCRYPT,
     job_nonenc varchar2(20), 
     job varchar2(20) ENCRYPT
) tablespace tde;

insert into emp_enc values('John','Wild',1,'10000','CurriculumA','CurriculumB');
commit;

exit;
EOF
