# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script drops and creates the HR.TEST_REGIONS table 
#   used for space monitoring labs.
#   Start this script connected as OS user: oracle.


sqlplus / as sysdba << EOF
set echo on

DROP TABLE hr.test_regions CASCADE CONSTRAINTS PURGE;

CREATE TABLE hr.test_regions 
( REGION_ID 	NUMBER
, REGION_NAME 	VARCHAR2(25)
)
TABLESPACE example PCTFREE 10 INITRANS 1 MAXTRANS 255
STORAGE (INITIAL 64K BUFFER_POOL DEFAULT)
NOLOGGING
/

list

exit;
EOF
