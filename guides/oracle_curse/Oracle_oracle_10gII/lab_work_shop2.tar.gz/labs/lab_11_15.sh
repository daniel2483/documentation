# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script drops the TBSALERT tablespace.
#   Start this script connected as OS user: oracle.

sqlplus / as sysdba << EOF

drop tablespace tbsalert including contents and datafiles;

exit;
EOF
