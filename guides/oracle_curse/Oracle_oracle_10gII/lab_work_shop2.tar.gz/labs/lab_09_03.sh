#!/bin/bash 
# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
users=8
x=1
y=$users
UNPW="addm/addm"

echo Wait for 8 stored procedures to complete...

while [ $x -le $y ]
do
    sqlplus -s $UNPW @/home/oracle/labs/test.sql &
    x=`expr $x + 1`
done

# This command causes this script to wait for all the above sqlplus
# calls to complete before going on. Without this, the user may think
# the script is finished in just a second, when in fact, they need to
# wait many seconds to see any output.
wait
exit
