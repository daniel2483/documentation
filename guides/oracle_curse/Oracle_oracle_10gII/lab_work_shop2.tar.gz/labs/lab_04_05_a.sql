-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
set echo on

ALTER DATABASE ADD LOGFILE MEMBER
'/u01/app/oracle/oradata/orcl/redo01b.log'
TO GROUP 1;

ALTER DATABASE ADD LOGFILE MEMBER
'/u01/app/oracle/oradata/orcl/redo02b.log'
TO GROUP 2;

ALTER DATABASE ADD LOGFILE MEMBER
'/u01/app/oracle/oradata/orcl/redo03b.log'
TO GROUP 3;


