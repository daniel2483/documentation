-- Oracle Database 10g: Administration Workshop II
-- Oracle Server Technologies - Curriculum Development
--
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
set echo on

CONNECT / as sysdba

EXEC dbms_advisor.set_default_task_parameter('ADDM','DB_ACTIVITY_MIN',30);

CONNECT addm/addm

DROP TABLE addm PURGE;
CREATE TABLE addm(id NUMBER, name VARCHAR2(2000));

EXEC DBMS_STATS.GATHER_TABLE_STATS(-
ownname=>'ADDM', tabname=>'ADDM',-
estimate_percent=>DBMS_STATS.AUTO_SAMPLE_SIZE);

exit

